import os
import sqlite3
import json
import secrets
from datetime import datetime, timedelta
from typing import Optional
from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import RedirectResponse, HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from passlib.hash import bcrypt
import jwt

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.getenv("ATLAS_DB_PATH", os.path.join(DATA_DIR, "atlas.db"))
SECRET_PATH = os.path.join(DATA_DIR, "secret.key")
ENV_SECRET = os.getenv("ATLAS_SECRET")

if ENV_SECRET:
    JWT_SECRET = ENV_SECRET.encode("utf-8")
else:
    if not os.path.exists(SECRET_PATH):
        with open(SECRET_PATH, "wb") as f:
            f.write(secrets.token_bytes(32))
    with open(SECRET_PATH, "rb") as f:
        JWT_SECRET = f.read()

def db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN('admin','viewer')),
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS cases(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS entities(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        kind TEXT NOT NULL,
        data TEXT DEFAULT '{}',
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS relations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        src_entity_id INTEGER NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        dst_entity_id INTEGER NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        kind TEXT NOT NULL,
        data TEXT DEFAULT '{}',
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS case_entities(
        case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
        entity_id INTEGER NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        PRIMARY KEY(case_id, entity_id)
    );
    CREATE TABLE IF NOT EXISTS events(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
        entity_id INTEGER REFERENCES entities(id) ON DELETE SET NULL,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        occurred_at TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS audit(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT NOT NULL,
        table_name TEXT NOT NULL,
        row_id INTEGER,
        at TEXT NOT NULL
    );
    """)
    conn.commit()
    conn.close()

def now():
    return datetime.utcnow().isoformat()

def create_token(user_id:int, role:str):
    payload = {"sub": user_id, "role": role, "exp": datetime.utcnow() + timedelta(hours=8), "iat": datetime.utcnow()}
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def decode_token(token:str):
    return jwt.decode(token, JWT_SECRET, algorithms=["HS256"])

def get_current_user(request: Request):
    token = request.cookies.get("access_token")
    if not token:
        return None
    try:
        payload = decode_token(token)
    except Exception:
        return None
    conn = db()
    cur = conn.execute("SELECT * FROM users WHERE id=?", (payload["sub"],))
    u = cur.fetchone()
    conn.close()
    return u

def require_user(u):
    if not u:
        raise HTTPException(status_code=401)

def require_admin(u):
    require_user(u)
    if u["role"] != "admin":
        raise HTTPException(status_code=403)

app = FastAPI()
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")

@app.on_event("startup")
def startup():
    init_db()

def render_dashboard(request: Request, user):
    conn = db()
    cc = conn.execute("SELECT COUNT(*) AS c FROM cases").fetchone()["c"]
    ec = conn.execute("SELECT COUNT(*) AS c FROM entities").fetchone()["c"]
    rc = conn.execute("SELECT COUNT(*) AS c FROM relations").fetchone()["c"]
    evc = conn.execute("SELECT COUNT(*) AS c FROM events").fetchone()["c"]
    conn.close()
    return templates.TemplateResponse("dashboard.html", {"request": request, "user": user, "cc": cc, "ec": ec, "rc": rc, "evc": evc})

@app.get("/favicon.ico")
def favicon():
    return Response(status_code=204)

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return RedirectResponse("/dashboard")

@app.get("/auth/register", response_class=HTMLResponse)
def register_page(request: Request):
    conn = db()
    c = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
    conn.close()
    if c > 0:
        return RedirectResponse("/auth/login")
    return templates.TemplateResponse("register.html", {"request": request})

@app.post("/auth/register")
def register(request: Request, username: str = Form(...), password: str = Form(...)):
    conn = db()
    c = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
    if c > 0:
        conn.close()
        raise HTTPException(status_code=403)
    ph = bcrypt.hash(password)
    conn.execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",(username,ph,"admin",now()))
    conn.commit()
    u = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    token = create_token(u["id"], u["role"])
    resp = render_dashboard(request, u)
    resp.set_cookie("access_token", token, httponly=True, samesite="lax", path="/", max_age=28800)
    return resp

@app.get("/auth/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/auth/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    conn = db()
    u = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    if not u or not bcrypt.verify(password, u["password_hash"]):
        raise HTTPException(status_code=401)
    token = create_token(u["id"], u["role"])
    resp = render_dashboard(request, u)
    resp.set_cookie("access_token", token, httponly=True, samesite="lax", path="/", max_age=28800)
    return resp

@app.get("/auth/logout")
def logout():
    resp = RedirectResponse("/auth/login", status_code=302)
    resp.delete_cookie("access_token", path="/")
    return resp

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    user = get_current_user(request)
    require_user(user)
    return render_dashboard(request, user)

@app.get("/entities", response_class=HTMLResponse)
def entities_page(request: Request):
    user = get_current_user(request)
    require_user(user)
    conn = db()
    rows = conn.execute("SELECT * FROM entities ORDER BY id DESC").fetchall()
    conn.close()
    return templates.TemplateResponse("entities.html", {"request": request, "user": user, "rows": rows})

@app.post("/entities/create")
def entities_create(request: Request, name: str = Form(...), kind: str = Form(...), data: str = Form("")):
    user = get_current_user(request)
    require_admin(user)
    try:
        json.loads(data or "{}")
    except Exception:
        data = "{}"
    conn = db()
    conn.execute("INSERT INTO entities(name,kind,data,created_at) VALUES(?,?,?,?)",(name,kind,data or "{}",now()))
    conn.execute("INSERT INTO audit(user_id,action,table_name,row_id,at) VALUES(?,?,?,?,?)",(user["id"],"create","entities",conn.execute("SELECT last_insert_rowid()").fetchone()[0],now()))
    conn.commit()
    conn.close()
    return RedirectResponse("/entities", status_code=302)

@app.post("/entities/delete/{entity_id}")
def entities_delete(request: Request, entity_id: int):
    user = get_current_user(request)
    require_admin(user)
    conn = db()
    conn.execute("DELETE FROM entities WHERE id=?", (entity_id,))
    conn.execute("INSERT INTO audit(user_id,action,table_name,row_id,at) VALUES(?,?,?,?,?)",(user["id"],"delete","entities",entity_id,now()))
    conn.commit()
    conn.close()
    return RedirectResponse("/entities", status_code=302)

@app.get("/cases", response_class=HTMLResponse)
def cases_page(request: Request):
    user = get_current_user(request)
    require_user(user)
    conn = db()
    rows = conn.execute("SELECT * FROM cases ORDER BY id DESC").fetchall()
    ent = conn.execute("SELECT id,name FROM entities ORDER BY id DESC").fetchall()
    conn.close()
    return templates.TemplateResponse("cases.html", {"request": request, "user": user, "rows": rows, "entities": ent})

@app.post("/cases/create")
def cases_create(request: Request, title: str = Form(...), description: str = Form("")):
    user = get_current_user(request)
    require_admin(user)
    conn = db()
    conn.execute("INSERT INTO cases(title,description,created_at) VALUES(?,?,?)",(title,description or "",now()))
    conn.execute("INSERT INTO audit(user_id,action,table_name,row_id,at) VALUES(?,?,?,?,?)",(user["id"],"create","cases",conn.execute("SELECT last_insert_rowid()").fetchone()[0],now()))
    conn.commit()
    conn.close()
    return RedirectResponse("/cases", status_code=302)

@app.post("/cases/attach")
def cases_attach_entity(request: Request, case_id: int = Form(...), entity_id: int = Form(...)):
    user = get_current_user(request)
    require_admin(user)
    conn = db()
    conn.execute("INSERT OR IGNORE INTO case_entities(case_id,entity_id) VALUES(?,?)",(case_id,entity_id))
    conn.execute("INSERT INTO audit(user_id,action,table_name,row_id,at) VALUES(?,?,?,?,?)",(user["id"],"attach","case_entities",case_id,now()))
    conn.commit()
    conn.close()
    return RedirectResponse("/cases", status_code=302)

@app.get("/relations", response_class=HTMLResponse)
def relations_page(request: Request):
    user = get_current_user(request)
    require_user(user)
    conn = db()
    rels = conn.execute("""
    SELECT r.id, r.kind, s.name AS src, d.name AS dst, r.created_at
    FROM relations r
    JOIN entities s ON r.src_entity_id=s.id
    JOIN entities d ON r.dst_entity_id=d.id
    ORDER BY r.id DESC
    """).fetchall()
    ents = conn.execute("SELECT id,name FROM entities ORDER BY name").fetchall()
    conn.close()
    return templates.TemplateResponse("relations.html", {"request": request, "user": user, "rels": rels, "ents": ents})

@app.post("/relations/create")
def relations_create(request: Request, src_entity_id: int = Form(...), dst_entity_id: int = Form(...), kind: str = Form(...), data: str = Form("")):
    user = get_current_user(request)
    require_admin(user)
    try:
        json.loads(data or "{}")
    except Exception:
        data = "{}"
    conn = db()
    conn.execute("INSERT INTO relations(src_entity_id,dst_entity_id,kind,data,created_at) VALUES(?,?,?,?,?)",(src_entity_id,dst_entity_id,kind,data or "{}",now()))
    conn.execute("INSERT INTO audit(user_id,action,table_name,row_id,at) VALUES(?,?,?,?,?)",(user["id"],"create","relations",conn.execute("SELECT last_insert_rowid()").fetchone()[0],now()))
    conn.commit()
    conn.close()
    return RedirectResponse("/relations", status_code=302)

@app.get("/timeline", response_class=HTMLResponse)
def timeline_page(request: Request):
    user = get_current_user(request)
    require_user(user)
    conn = db()
    cases = conn.execute("SELECT id,title FROM cases ORDER BY id DESC").fetchall()
    events = conn.execute("""
    SELECT e.id, e.title, e.description, e.occurred_at, c.title AS case_title, en.name AS entity_name
    FROM events e
    JOIN cases c ON e.case_id=c.id
    LEFT JOIN entities en ON e.entity_id=en.id
    ORDER BY occurred_at DESC
    """).fetchall()
    conn.close()
    return templates.TemplateResponse("timeline.html", {"request": request, "user": user, "cases": cases, "events": events})

@app.post("/events/create")
def events_create(request: Request, case_id: int = Form(...), title: str = Form(...), description: str = Form(""), occurred_at: str = Form(...), entity_id: Optional[int] = Form(None)):
    user = get_current_user(request)
    require_admin(user)
    conn = db()
    conn.execute("INSERT INTO events(case_id,entity_id,title,description,occurred_at,created_at) VALUES(?,?,?,?,?,?)",(case_id,entity_id,title,description or "",occurred_at,now()))
    conn.execute("INSERT INTO audit(user_id,action,table_name,row_id,at) VALUES(?,?,?,?,?)",(user["id"],"create","events",conn.execute("SELECT last_insert_rowid()").fetchone()[0],now()))
    conn.commit()
    conn.close()
    return RedirectResponse("/timeline", status_code=302)

@app.get("/search", response_class=HTMLResponse)
def search_page(request: Request, q: Optional[str] = None):
    user = get_current_user(request)
    require_user(user)
    conn = db()
    res_cases = []
    res_entities = []
    res_events = []
    if q:
        like = f"%{q}%"
        res_cases = conn.execute("SELECT id,title,description FROM cases WHERE title LIKE ? OR description LIKE ? ORDER BY id DESC",(like, like)).fetchall()
        res_entities = conn.execute("SELECT id,name,kind FROM entities WHERE name LIKE ? OR kind LIKE ? ORDER BY id DESC",(like, like)).fetchall()
        res_events = conn.execute("SELECT id,title,description,occurred_at FROM events WHERE title LIKE ? OR description LIKE ? ORDER BY occurred_at DESC",(like, like)).fetchall()
    conn.close()
    return templates.TemplateResponse("search.html", {"request": request, "user": user, "q": q or "", "res_cases": res_cases, "res_entities": res_entities, "res_events": res_events})

@app.get("/graph", response_class=HTMLResponse)
def graph_page(request: Request):
    user = get_current_user(request)
    require_user(user)
    return templates.TemplateResponse("graph.html", {"request": request, "user": user})

@app.get("/graph-data")
def graph_data(request: Request):
    user = get_current_user(request)
    require_user(user)
    conn = db()
    ents = conn.execute("SELECT id,name,kind FROM entities").fetchall()
    rels = conn.execute("SELECT id,src_entity_id,dst_entity_id,kind FROM relations").fetchall()
    conn.close()
    nodes = [{"data":{"id": f"e{e['id']}", "label": e["name"], "kind": e["kind"]}} for e in ents]
    edges = [{"data":{"id": f"r{r['id']}", "source": f"e{r['src_entity_id']}", "target": f"e{r['dst_entity_id']}", "label": r["kind"]}} for r in rels]
    return JSONResponse({"nodes": nodes, "edges": edges})
