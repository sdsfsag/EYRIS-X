import os
os.environ["ATLAS_DB_PATH"] = os.path.abspath("data/test.db")
os.environ["ATLAS_SECRET"] = "test-secret"
from fastapi.testclient import TestClient
import app

def test_register_and_login():
    app.init_db()
    client = TestClient(app.app)
    r = client.get("/auth/register")
    assert r.status_code == 200
    r = client.post("/auth/register", data={"username":"u1","password":"p1"})
    assert r.status_code == 200
    r = client.get("/dashboard")
    assert r.status_code == 200
    client.get("/auth/logout")
    r = client.get("/dashboard")
    assert r.status_code == 401
    r = client.post("/auth/login", data={"username":"u1","password":"p1"})
    assert r.status_code == 200
    r = client.get("/dashboard")
    assert r.status_code == 200
