# Atlas Lite v2
Lokales, privacy-first Research-Tool mit Entities, Relations, Cases, Timeline, Suche, Graph. Läuft offline.

## Start
python -m venv .venv
. .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app:app --reload

Erster Start: /auth/register aufrufen, Admin anlegen.
